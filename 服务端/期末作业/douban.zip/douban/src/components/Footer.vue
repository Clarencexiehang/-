<template>
  <div class="box">
      <div class="items">
          黔ICP备2022000903号
      </div>
      <div class="items"> 
          qq邮箱：2118116004@qq.com
      </div>
  </div>
</template>

<script>
export default {

}
</script>

<style lang='scss' scoped>
.box{
    height: 50px;
    background-color:#efefef ;
    display: flex;
    justify-content: center;
    margin-top: 100px;
    .items{
        width: 50%;
        text-align: center;
        line-height: 50px;
        height: 50px;
        color: #fff;
    }
}
</style>